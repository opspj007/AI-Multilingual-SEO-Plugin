<?php
/**
 * Plugin Name: AI Multilingual SEO
 * Description: Localize pages, products, SEO metadata and blog posts with AI-assisted translation, human review & approval, hreflang, language-specific sitemaps and WooCommerce support.
 * Version: 1.0.0
 * Requires PHP: 7.4
 * Requires at least: 5.8
 * License: GPL-2.0-or-later
 * Text Domain: wpaml
 */
defined( 'ABSPATH' ) || exit;

define( 'WPAML_VERSION', '1.0.0' );
define( 'WPAML_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPAML_URL', plugin_dir_url( __FILE__ ) );

foreach ( [ 'languages', 'settings', 'translations', 'seo', 'ai', 'translator', 'front', 'sitemap', 'woo', 'admin' ] as $wpaml_f ) {
	require_once WPAML_DIR . "includes/{$wpaml_f}.php";
}

register_activation_hook( __FILE__, function () {
	WPAML_Sitemap::rules();
	flush_rewrite_rules();
} );
register_deactivation_hook( __FILE__, 'flush_rewrite_rules' );

add_action( 'plugins_loaded', function () {
	WPAML_Settings::init();
	WPAML_T::init();
	WPAML_SEO::init();
	WPAML_Front::init();
	WPAML_Sitemap::init();
	WPAML_Woo::init();
	if ( is_admin() ) {
		WPAML_Admin::init();
	}
} );
