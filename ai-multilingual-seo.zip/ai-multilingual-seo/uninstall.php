<?php
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;
delete_option( 'wpaml_settings' );
delete_option( 'wpaml_sm_v' );
// Translations are ordinary posts and are intentionally left in place.
