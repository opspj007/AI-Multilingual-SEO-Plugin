<?php
defined( 'ABSPATH' ) || exit;

/** Translation pipeline: prompts, chunking, integrity checks, and the run() entry point. */
class WPAML_Translator {

	/** Translate $source_id into $lang, creating/updating the translation post. Returns post ID or WP_Error. */
	static function run( $source_id, $lang, $force = false ) {
		if ( ! WPAML_AI::configured() ) return new WP_Error( 'noai', 'Add your AI API key under Multilingual SEO → Settings.' );
		$src = get_post( $source_id );
		if ( ! $src ) return new WP_Error( 'nosrc', 'Source post not found.' );

		$all      = WPAML_T::translations( $source_id );
		$existing = $all[ $lang ] ?? null;
		if ( $existing && ! $force ) return new WP_Error( 'exists', 'A translation already exists. Use re-translate to overwrite it.' );

		$id = WPAML_T::create( $source_id, $lang );
		if ( is_wp_error( $id ) ) return $id;

		$f = self::fields( $src, $lang );
		if ( is_wp_error( $f ) ) return $f;

		$warning = $f['warning'] ?? '';
		unset( $f['warning'] );
		WPAML_T::apply_fields( $id, $f );

		if ( 'publish' === get_post_status( $id ) ) wp_update_post( [ 'ID' => $id, 'post_status' => 'draft' ] ); // re-translation must be re-approved
		update_post_meta( $id, '_wpaml_status', 'review' );
		update_post_meta( $id, '_wpaml_source_hash', WPAML_T::source_hash( $source_id ) );
		update_post_meta( $id, '_wpaml_ai_model', WPAML_AI::model() );
		update_post_meta( $id, '_wpaml_translated_at', time() );
		$warning ? update_post_meta( $id, '_wpaml_warning', $warning ) : delete_post_meta( $id, '_wpaml_warning' );
		delete_post_meta( $id, '_wpaml_note' );

		if ( WPAML_Settings::get( 'auto_publish' ) && ! $warning ) WPAML_T::approve( $id, 0 );
		WPAML_T::flush();
		do_action( 'wpaml_translated', $id, $source_id, $lang );
		return $id;
	}

	static function glossary( $lang ) {
		$out = [];
		foreach ( preg_split( '/\R/', (string) WPAML_Settings::get( 'glossary' ) ) as $line ) {
			$line = trim( $line );
			if ( '' === $line || false === strpos( $line, '=' ) ) continue;
			if ( preg_match( '/^([a-z]{2,3}(?:-[a-z]{2,4})?)\s*:\s*(.+)$/i', $line, $m ) ) {
				if ( strtolower( $m[1] ) !== $lang ) continue; // scoped to another language
				$line = $m[2];
			}
			$out[] = $line;
		}
		return $out;
	}

	static function system( $lang, $json ) {
		$src = WPAML_Languages::name( WPAML_Languages::default_lang() );
		$tgt = WPAML_Languages::name( $lang );
		$r   = [
			'You are a professional localization specialist and international SEO copywriter.',
			"Translate from $src into $tgt for native $tgt-speaking customers. Write natural, idiomatic copy, not literal word-for-word output.",
			'Tone and style: ' . trim( (string) WPAML_Settings::get( 'tone' ) ),
			'Preserve exactly: all HTML tags and attributes, WordPress block comments (<!-- wp:... -->), shortcodes (e.g. [gallery id="1"]), URLs, email addresses, code, CSS classes, numbers and placeholders such as %s or {name}. You may translate human-readable attribute text such as alt, title and placeholder.',
			'Never add explanations, notes or markdown fences.',
		];
		if ( $g = self::glossary( $lang ) ) $r[] = "Use this glossary strictly:\n- " . implode( "\n- ", $g );
		if ( $d = trim( (string) WPAML_Settings::get( 'dnt' ) ) ) $r[] = 'Never translate these brand/product terms: ' . $d;
		$r[] = $json
			? 'Return ONLY a JSON object with string keys: title, excerpt, slug, seo_title, seo_description, focus_keyword. "slug" is a short URL slug in the target language (lowercase, words separated by hyphens). "seo_title" max 60 characters. "seo_description" max 155 characters, persuasive, containing the focus keyword. "focus_keyword" is the phrase a native speaker would actually search for (localize it, do not translate literally). If the source seo_title/seo_description are empty, write them from content_preview. Use an empty string for excerpt if the source excerpt is empty.'
			: 'Return ONLY the translated HTML, preserving its structure.';
		return implode( "\n", $r );
	}

	static function fields( $src, $lang ) {
		$seo   = WPAML_SEO::read( $src->ID );
		$input = [
			'title'           => $src->post_title,
			'excerpt'         => $src->post_excerpt,
			'seo_title'       => $seo['title'],
			'seo_description' => $seo['desc'],
			'focus_keyword'   => $seo['kw'],
			'content_preview' => wp_trim_words( wp_strip_all_tags( strip_shortcodes( $src->post_content ) ), 150, '' ),
		];
		$raw = WPAML_AI::complete( self::system( $lang, true ), wp_json_encode( $input, JSON_UNESCAPED_UNICODE ), 2000 );
		if ( is_wp_error( $raw ) ) return $raw;
		$m = self::parse_json( $raw );
		if ( ! $m ) return new WP_Error( 'parse', 'The AI response could not be parsed. Please try again.' );

		$out = [
			'title'   => sanitize_text_field( $m['title'] ?? '' ) ?: $src->post_title,
			'excerpt' => wp_kses_post( $m['excerpt'] ?? '' ),
			'slug'    => sanitize_title( $m['slug'] ?? '' ),
			'seo'     => [
				'title' => sanitize_text_field( $m['seo_title'] ?? '' ),
				'desc'  => sanitize_text_field( $m['seo_description'] ?? '' ),
				'kw'    => sanitize_text_field( $m['focus_keyword'] ?? '' ),
			],
		];
		if ( '' !== trim( $src->post_content ) ) {
			$parts = [];
			foreach ( self::chunks( $src->post_content ) as $chunk ) {
				$t = WPAML_AI::complete( self::system( $lang, false ), $chunk, 8000 );
				if ( is_wp_error( $t ) ) return $t;
				$parts[] = self::unfence( $t );
			}
			$out['content'] = implode( "\n\n", $parts );
			$out['warning'] = self::integrity( $src->post_content, $out['content'] );
		}
		return $out;
	}

	/** Split at blank lines into ~5k-char pieces so long posts translate reliably. */
	static function chunks( $html, $max = 5000 ) {
		$out = [];
		$cur = '';
		foreach ( explode( "\n\n", $html ) as $block ) {
			if ( '' !== $cur && strlen( $cur ) + strlen( $block ) > $max ) {
				$out[] = $cur;
				$cur   = '';
			}
			$cur .= ( '' === $cur ? '' : "\n\n" ) . $block;
		}
		if ( '' !== $cur ) $out[] = $cur;
		return $out;
	}

	static function unfence( $t ) {
		return preg_replace( '/^```[a-z]*\s*|\s*```$/i', '', trim( $t ) );
	}

	static function parse_json( $raw ) {
		$raw = self::unfence( $raw );
		$a   = strpos( $raw, '{' );
		$b   = strrpos( $raw, '}' );
		if ( false === $a || false === $b ) return null;
		$d = json_decode( substr( $raw, $a, $b - $a + 1 ), true );
		return is_array( $d ) ? $d : null;
	}

	/** Compare structural markers between source and translation; returns a warning string or ''. */
	static function integrity( $a, $b ) {
		$checks = [ 'block comments' => '/<!--\s*wp:/', 'links' => '/<a\s/i', 'images' => '/<img\s/i', 'shortcodes' => '/\[[a-z_][\w-]*[\s\]]/i' ];
		$bad    = [];
		foreach ( $checks as $label => $re ) {
			if ( preg_match_all( $re, $a ) !== preg_match_all( $re, $b ) ) $bad[] = $label;
		}
		return $bad ? 'Structure differs from the source (' . implode( ', ', $bad ) . '). Review carefully before approving.' : '';
	}
}
