<?php
defined( 'ABSPATH' ) || exit;

/** Multilingual SEO metadata: SEO-plugin adapter, hreflang, <html lang>, own title/description/OG when no SEO plugin. */
class WPAML_SEO {

	static function engine() {
		if ( defined( 'WPSEO_VERSION' ) ) return 'yoast';
		if ( defined( 'RANK_MATH_VERSION' ) || class_exists( 'RankMath' ) ) return 'rankmath';
		return 'own';
	}

	static function keys() {
		switch ( self::engine() ) {
			case 'yoast':    return [ 'title' => '_yoast_wpseo_title', 'desc' => '_yoast_wpseo_metadesc', 'kw' => '_yoast_wpseo_focuskw' ];
			case 'rankmath': return [ 'title' => 'rank_math_title', 'desc' => 'rank_math_description', 'kw' => 'rank_math_focus_keyword' ];
			default:         return [ 'title' => '_wpaml_seo_title', 'desc' => '_wpaml_seo_desc', 'kw' => '_wpaml_seo_kw' ];
		}
	}

	static function read( $id ) {
		$k = self::keys();
		return [
			'title' => (string) get_post_meta( $id, $k['title'], true ),
			'desc'  => (string) get_post_meta( $id, $k['desc'], true ),
			'kw'    => (string) get_post_meta( $id, $k['kw'], true ),
		];
	}

	static function write( $id, $v ) {
		$k = self::keys();
		foreach ( [ 'title', 'desc', 'kw' ] as $f ) {
			if ( isset( $v[ $f ] ) ) update_post_meta( $id, $k[ $f ], sanitize_text_field( $v[ $f ] ) );
		}
	}

	private static function len( $s ) { return function_exists( 'mb_strlen' ) ? mb_strlen( $s ) : strlen( $s ); }

	/** List of SEO problems for the dashboard. */
	static function audit( $id ) {
		$s = self::read( $id );
		$i = [];
		$tl = self::len( $s['title'] );
		if ( ! $tl ) $i[] = 'No SEO title'; elseif ( $tl > 60 ) $i[] = 'SEO title over 60 chars';
		$dl = self::len( $s['desc'] );
		if ( ! $dl ) $i[] = 'No meta description'; elseif ( $dl > 160 ) $i[] = 'Description over 160 chars'; elseif ( $dl < 70 ) $i[] = 'Description under 70 chars';
		return $i;
	}

	static function init() {
		add_action( 'wp_head', [ __CLASS__, 'head' ], 1 );
		add_filter( 'language_attributes', [ __CLASS__, 'lang_attr' ] );
		if ( 'own' === self::engine() ) add_filter( 'pre_get_document_title', [ __CLASS__, 'title' ], 20 );
	}

	private static function queried() {
		if ( ! is_singular() ) return 0;
		$id = get_queried_object_id();
		return ( $id && in_array( get_post_type( $id ), WPAML_T::enabled_types(), true ) ) ? $id : 0;
	}

	static function lang_attr( $out ) {
		$id = self::queried();
		if ( ! $id ) return $out;
		$lang = WPAML_T::lang( $id );
		$out  = preg_replace( '/\s(lang|dir)="[^"]*"/', '', $out );
		return trim( $out ) . ' lang="' . esc_attr( WPAML_Languages::hreflang( $lang ) ) . '" dir="' . ( WPAML_Languages::rtl( $lang ) ? 'rtl' : 'ltr' ) . '"';
	}

	static function title( $t ) {
		$id = self::queried();
		if ( ! $id ) return $t;
		$s = self::read( $id );
		return '' !== $s['title'] ? $s['title'] : $t;
	}

	static function head() {
		$id = self::queried();
		if ( ! $id ) return;
		if ( WPAML_Settings::get( 'hreflang' ) ) self::hreflang( $id );
		if ( 'own' === self::engine() ) self::meta( $id );
	}

	static function hreflang( $id ) {
		$group = WPAML_T::published_group( $id );
		if ( count( $group ) < 2 ) return;
		foreach ( $group as $lang => $p ) {
			printf( "<link rel=\"alternate\" hreflang=\"%s\" href=\"%s\" />\n", esc_attr( WPAML_Languages::hreflang( $lang ) ), esc_url( get_permalink( $p ) ) );
		}
		$d = WPAML_Languages::default_lang();
		if ( isset( $group[ $d ] ) ) printf( "<link rel=\"alternate\" hreflang=\"x-default\" href=\"%s\" />\n", esc_url( get_permalink( $group[ $d ] ) ) );
	}

	private static function meta( $id ) {
		$s    = self::read( $id );
		$lang = WPAML_T::lang( $id );
		$desc = $s['desc'] ?: '';
		if ( $desc ) printf( "<meta name=\"description\" content=\"%s\" />\n", esc_attr( $desc ) );
		printf( "<meta property=\"og:locale\" content=\"%s\" />\n", esc_attr( WPAML_Languages::locale( $lang ) ) );
		foreach ( WPAML_T::published_group( $id ) as $l => $p ) {
			if ( $l !== $lang ) printf( "<meta property=\"og:locale:alternate\" content=\"%s\" />\n", esc_attr( WPAML_Languages::locale( $l ) ) );
		}
		printf( "<meta property=\"og:title\" content=\"%s\" />\n", esc_attr( $s['title'] ?: get_the_title( $id ) ) );
		if ( $desc ) printf( "<meta property=\"og:description\" content=\"%s\" />\n", esc_attr( $desc ) );
		printf( "<meta property=\"og:url\" content=\"%s\" />\n<meta property=\"og:type\" content=\"%s\" />\n<meta property=\"og:site_name\" content=\"%s\" />\n", esc_url( get_permalink( $id ) ), 'product' === get_post_type( $id ) ? 'product' : 'article', esc_attr( get_bloginfo( 'name' ) ) );
	}
}
