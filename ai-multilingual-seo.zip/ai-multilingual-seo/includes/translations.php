<?php
defined( 'ABSPATH' ) || exit;

/**
 * Data layer. Every translation is a real post (same post type) linked to its source:
 *   _wpaml_source  = source post ID      _wpaml_lang   = language code
 *   _wpaml_status  = pending|review|approved|rejected
 *   _wpaml_source_hash = fingerprint of the source when the translation was last made/approved
 * Posts without _wpaml_lang are originals in the default language.
 */
class WPAML_T {
	private static $cache = [];

	static function init() {
		add_action( 'transition_post_status', [ __CLASS__, 'on_transition' ], 10, 3 );
		add_action( 'wp_trash_post', [ __CLASS__, 'on_trash' ] );
	}

	static function statuses() {
		return [
			'pending'  => 'Not translated yet',
			'review'   => 'Needs review',
			'approved' => 'Approved',
			'rejected' => 'Rejected',
		];
	}

	static function enabled_types() {
		return array_values( array_filter( (array) WPAML_Settings::get( 'post_types' ), 'post_type_exists' ) );
	}

	static function is_translation( $id ) { return (bool) get_post_meta( $id, '_wpaml_lang', true ); }
	static function lang( $id ) { return get_post_meta( $id, '_wpaml_lang', true ) ?: WPAML_Languages::default_lang(); }
	static function status( $id ) { return get_post_meta( $id, '_wpaml_status', true ); }
	static function source_id( $id ) { return (int) get_post_meta( $id, '_wpaml_source', true ) ?: (int) $id; }
	static function flush() { self::$cache = []; }

	/** [ lang => WP_Post ] translations of a source post. */
	static function translations( $source_id ) {
		$source_id = (int) $source_id;
		if ( isset( self::$cache[ $source_id ] ) ) return self::$cache[ $source_id ];
		$types = self::enabled_types();
		$out   = [];
		if ( $types ) {
			$posts = get_posts( [
				'post_type'   => $types,
				'post_status' => [ 'publish', 'draft', 'pending', 'private', 'future' ],
				'meta_key'    => '_wpaml_source',
				'meta_value'  => $source_id,
				'numberposts' => -1,
				'wpaml_skip'  => true,
			] );
			foreach ( $posts as $p ) $out[ self::lang( $p->ID ) ] = $p;
		}
		return self::$cache[ $source_id ] = $out;
	}

	/** [ lang => WP_Post ] including the source in the default language. */
	static function group( $id ) {
		$sid = self::source_id( $id );
		$src = get_post( $sid );
		$out = $src ? [ WPAML_Languages::default_lang() => $src ] : [];
		return $out + self::translations( $sid );
	}

	static function published_group( $id ) {
		return array_filter( self::group( $id ), function ( $p ) { return 'publish' === $p->post_status; } );
	}

	static function source_hash( $sid ) {
		$p = get_post( $sid );
		if ( ! $p ) return '';
		$s = WPAML_SEO::read( $sid );
		return md5( wp_json_encode( [ $p->post_title, $p->post_content, $p->post_excerpt, $s['title'], $s['desc'] ] ) );
	}

	static function outdated( $tr_id ) {
		return get_post_meta( $tr_id, '_wpaml_source_hash', true ) !== self::source_hash( self::source_id( $tr_id ) );
	}

	/** Returns WP_Error if this post can't be translated safely, else null. */
	static function unsupported( $post ) {
		if ( get_post_meta( $post->ID, '_elementor_data', true ) || 'on' === get_post_meta( $post->ID, '_et_pb_use_builder', true ) ) {
			return new WP_Error( 'builder', 'Page-builder content (Elementor/Divi) is not supported yet. Use the block or classic editor.' );
		}
		if ( 'product' === $post->post_type && has_term( 'variable', 'product_type', $post ) ) {
			return new WP_Error( 'variable', 'Variable products are not supported yet (variations cannot be duplicated safely). Simple, external and grouped products work.' );
		}
		return null;
	}

	private static function skip_meta( $k ) {
		foreach ( [ '_wpaml_', '_yoast_wpseo_', 'rank_math_', '_elementor_', '_edit_', '_wp_old_slug', '_wp_trash_', '_wp_desired_post_slug', '_sku', 'total_sales', '_wc_average_rating', '_wc_review_count', '_wc_rating_count', '_oembed_' ] as $p ) {
			if ( 0 === strpos( $k, $p ) ) return true;
		}
		return false;
	}

	/** Create (or return existing) translation shell. Returns post ID or WP_Error. */
	static function create( $source_id, $lang, $f = [] ) {
		$src = get_post( $source_id );
		if ( ! $src ) return new WP_Error( 'nosrc', 'Source post not found.' );
		if ( self::is_translation( $src->ID ) ) return new WP_Error( 'istrans', 'Translate the original post, not a translation.' );
		if ( ! in_array( $src->post_type, self::enabled_types(), true ) ) return new WP_Error( 'type', 'This post type is not enabled for translation.' );
		if ( ! WPAML_Languages::is_target( $lang ) ) return new WP_Error( 'lang', 'Language is not enabled in settings.' );

		$existing = self::translations( $src->ID );
		if ( isset( $existing[ $lang ] ) ) return $existing[ $lang ]->ID;
		if ( $err = self::unsupported( $src ) ) return $err;

		$parent = 0;
		if ( $src->post_parent ) {
			$pt = self::translations( $src->post_parent );
			if ( isset( $pt[ $lang ] ) ) $parent = $pt[ $lang ]->ID;
		}
		$id = wp_insert_post( wp_slash( [
			'post_type'      => $src->post_type,
			'post_status'    => 'draft',
			'post_title'     => $f['title'] ?? $src->post_title,
			'post_content'   => $f['content'] ?? $src->post_content,
			'post_excerpt'   => $f['excerpt'] ?? $src->post_excerpt,
			'post_name'      => ! empty( $f['slug'] ) ? sanitize_title( $f['slug'] ) : '',
			'post_author'    => get_current_user_id() ?: $src->post_author,
			'post_parent'    => $parent,
			'menu_order'     => $src->menu_order,
			'comment_status' => $src->comment_status,
		] ), true );
		if ( is_wp_error( $id ) ) return $id;

		foreach ( get_post_meta( $src->ID ) as $k => $vals ) {
			if ( self::skip_meta( $k ) ) continue;
			foreach ( $vals as $v ) add_post_meta( $id, $k, wp_slash( maybe_unserialize( $v ) ) );
		}
		foreach ( get_object_taxonomies( $src->post_type ) as $tax ) {
			$ids = wp_get_object_terms( $src->ID, $tax, [ 'fields' => 'ids' ] );
			if ( ! is_wp_error( $ids ) && $ids ) wp_set_object_terms( $id, array_map( 'intval', $ids ), $tax );
		}
		update_post_meta( $id, '_wpaml_lang', $lang );
		update_post_meta( $id, '_wpaml_source', $src->ID );
		update_post_meta( $id, '_wpaml_status', 'pending' );
		self::flush();
		do_action( 'wpaml_translation_created', $id, $src->ID, $lang );
		return $id;
	}

	/** Write translated fields. Keys: title, content, excerpt, slug, seo[title,desc,kw]. */
	static function apply_fields( $id, $f ) {
		$upd = [ 'ID' => $id ];
		foreach ( [ 'title' => 'post_title', 'content' => 'post_content', 'excerpt' => 'post_excerpt' ] as $k => $col ) {
			if ( isset( $f[ $k ] ) ) $upd[ $col ] = $f[ $k ];
		}
		if ( ! empty( $f['slug'] ) ) $upd['post_name'] = sanitize_title( $f['slug'] );
		if ( count( $upd ) > 1 ) wp_update_post( wp_slash( $upd ) );
		if ( ! empty( $f['seo'] ) ) WPAML_SEO::write( $id, $f['seo'] );
	}

	static function approve( $id, $user = 0 ) {
		$sid = self::source_id( $id );
		$src = get_post( $sid );
		$upd = [ 'ID' => $id ];
		if ( $src && in_array( $src->post_status, [ 'publish', 'private' ], true ) ) $upd['post_status'] = $src->post_status;
		wp_update_post( $upd );
		update_post_meta( $id, '_wpaml_status', 'approved' );
		update_post_meta( $id, '_wpaml_reviewed_by', (int) $user );
		update_post_meta( $id, '_wpaml_reviewed_at', time() );
		update_post_meta( $id, '_wpaml_source_hash', self::source_hash( $sid ) );
		delete_post_meta( $id, '_wpaml_note' );
		delete_post_meta( $id, '_wpaml_warning' );
		self::flush();
		do_action( 'wpaml_translation_approved', $id );
	}

	static function reject( $id, $note = '' ) {
		wp_update_post( [ 'ID' => $id, 'post_status' => 'draft' ] );
		update_post_meta( $id, '_wpaml_status', 'rejected' );
		update_post_meta( $id, '_wpaml_note', sanitize_textarea_field( $note ) );
		self::flush();
	}

	/** Publish approved translations when a scheduled/draft source goes live. */
	static function on_transition( $new, $old, $post ) {
		if ( 'publish' !== $new || 'publish' === $old || self::is_translation( $post->ID ) ) return;
		self::flush();
		foreach ( self::translations( $post->ID ) as $tr ) {
			if ( 'approved' === self::status( $tr->ID ) && 'publish' !== $tr->post_status ) {
				wp_update_post( [ 'ID' => $tr->ID, 'post_status' => 'publish' ] );
			}
		}
		self::flush();
	}

	static function on_trash( $id ) {
		if ( self::is_translation( $id ) ) return;
		foreach ( self::translations( $id ) as $tr ) wp_trash_post( $tr->ID );
		self::flush();
	}
}
