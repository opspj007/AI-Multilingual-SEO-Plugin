<?php
defined( 'ABSPATH' ) || exit;

/**
 * WooCommerce compatibility.
 *  - Translated products are real products; price/stock/dimensions mirror the source on every save.
 *  - Adding a translated product to the cart adds the SOURCE product, so orders, stock and reports stay unified.
 *  - Variable products are not supported yet (blocked at creation with a clear message).
 */
class WPAML_Woo {

	static function init() {
		if ( ! class_exists( 'WooCommerce' ) ) return;
		add_filter( 'woocommerce_add_to_cart_product_id', [ __CLASS__, 'to_source' ] );
		add_action( 'woocommerce_update_product', [ __CLASS__, 'sync' ], 20 );
		add_action( 'woocommerce_product_set_stock', [ __CLASS__, 'sync_stock' ] );
	}

	static function to_source( $id ) {
		$s = (int) get_post_meta( $id, '_wpaml_source', true );
		return ( $s && 'product' === get_post_type( $id ) ) ? $s : $id;
	}

	private static function translations_of( $product_id ) {
		if ( WPAML_T::is_translation( $product_id ) || 'product' !== get_post_type( $product_id ) ) return [];
		WPAML_T::flush();
		return WPAML_T::translations( $product_id );
	}

	static function sync( $product_id ) {
		$trs = self::translations_of( $product_id );
		if ( ! $trs ) return;
		$src = wc_get_product( $product_id );
		if ( ! $src ) return;
		foreach ( $trs as $tr ) {
			$t = wc_get_product( $tr->ID );
			if ( ! $t ) continue;
			$t->set_regular_price( $src->get_regular_price( 'edit' ) );
			$t->set_sale_price( $src->get_sale_price( 'edit' ) );
			$t->set_date_on_sale_from( $src->get_date_on_sale_from( 'edit' ) );
			$t->set_date_on_sale_to( $src->get_date_on_sale_to( 'edit' ) );
			$t->set_tax_status( $src->get_tax_status( 'edit' ) );
			$t->set_tax_class( $src->get_tax_class( 'edit' ) );
			$t->set_manage_stock( $src->get_manage_stock( 'edit' ) );
			$t->set_stock_quantity( $src->get_stock_quantity( 'edit' ) );
			$t->set_stock_status( $src->get_stock_status( 'edit' ) );
			$t->set_backorders( $src->get_backorders( 'edit' ) );
			$t->set_sold_individually( $src->get_sold_individually( 'edit' ) );
			$t->set_weight( $src->get_weight( 'edit' ) );
			$t->set_length( $src->get_length( 'edit' ) );
			$t->set_width( $src->get_width( 'edit' ) );
			$t->set_height( $src->get_height( 'edit' ) );
			$t->set_gallery_image_ids( $src->get_gallery_image_ids( 'edit' ) );
			if ( ! $t->get_image_id( 'edit' ) ) $t->set_image_id( $src->get_image_id( 'edit' ) );
			$t->save();
		}
	}

	/** Orders reduce source stock without firing woocommerce_update_product — mirror it here. */
	static function sync_stock( $product ) {
		$id  = $product->get_id();
		$trs = self::translations_of( $id );
		if ( ! $trs || ! $product->get_manage_stock() ) return;
		foreach ( $trs as $tr ) {
			$t = wc_get_product( $tr->ID );
			if ( $t ) wc_update_product_stock( $t, $product->get_stock_quantity(), 'set' );
		}
	}
}
