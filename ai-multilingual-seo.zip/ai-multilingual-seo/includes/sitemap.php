<?php
defined( 'ABSPATH' ) || exit;

/**
 * Language-specific XML sitemaps with hreflang alternates:
 *   /wpaml-sitemap.xml        index
 *   /wpaml-sitemap-{lang}.xml per-language urlset (?page=N beyond 1000 URLs)
 * Translations are removed from the core wp-sitemap.xml so each URL is listed once per sitemap family.
 */
class WPAML_Sitemap {
	const PER = 1000;

	static function init() {
		add_action( 'init', [ __CLASS__, 'rules' ] );
		add_filter( 'query_vars', function ( $v ) { $v[] = 'wpaml_sitemap'; return $v; } );
		add_action( 'template_redirect', [ __CLASS__, 'serve' ], 1 );
		add_filter( 'robots_txt', [ __CLASS__, 'robots' ], 20 );
		add_filter( 'wp_sitemaps_posts_query_args', [ __CLASS__, 'core_exclude' ] );
		add_action( 'save_post', [ __CLASS__, 'bust' ] );
	}

	static function rules() {
		add_rewrite_rule( '^wpaml-sitemap\.xml$', 'index.php?wpaml_sitemap=index', 'top' );
		add_rewrite_rule( '^wpaml-sitemap-([a-z]{2,3}(?:-[a-z]{2,4})?)\.xml$', 'index.php?wpaml_sitemap=$matches[1]', 'top' );
	}

	static function url( $lang = 'index', $page = 1 ) {
		$u = get_option( 'permalink_structure' )
			? home_url( '/wpaml-sitemap' . ( 'index' === $lang ? '' : '-' . $lang ) . '.xml' )
			: add_query_arg( 'wpaml_sitemap', $lang, home_url( '/' ) );
		return $page > 1 ? add_query_arg( 'page', $page, $u ) : $u;
	}

	static function bust( $post_id ) {
		if ( wp_is_post_revision( $post_id ) || wp_is_post_autosave( $post_id ) ) return;
		update_option( 'wpaml_sm_v', time(), false );
	}

	static function robots( $out ) {
		return $out . "\nSitemap: " . self::url() . "\n";
	}

	static function core_exclude( $args ) {
		$args['meta_query'][] = [ 'key' => '_wpaml_lang', 'compare' => 'NOT EXISTS' ];
		$args['wpaml_skip']   = true;
		return $args;
	}

	private static function query_args( $lang ) {
		return [
			'post_type'     => WPAML_T::enabled_types() ?: [ 'post' ],
			'post_status'   => 'publish',
			'has_password'  => false,
			'orderby'       => 'ID',
			'order'         => 'ASC',
			'fields'        => 'ids',
			'wpaml_skip'    => true,
			'meta_query'    => [ $lang === WPAML_Languages::default_lang()
				? [ 'key' => '_wpaml_lang', 'compare' => 'NOT EXISTS' ]
				: [ 'key' => '_wpaml_lang', 'value' => $lang ] ],
		];
	}

	static function serve() {
		$v = get_query_var( 'wpaml_sitemap' );
		if ( ! $v ) return;
		$v = strtolower( sanitize_text_field( $v ) );
		if ( 'index' !== $v && ! WPAML_Languages::is_enabled( $v ) ) {
			global $wp_query;
			$wp_query->set_404();
			status_header( 404 );
			nocache_headers();
			return;
		}
		$page = isset( $_GET['page'] ) ? max( 1, (int) $_GET['page'] ) : 1;
		$key  = 'wpaml_sm_' . get_option( 'wpaml_sm_v', 0 ) . '_' . $v . '_' . $page;
		$xml  = get_transient( $key );
		if ( false === $xml ) {
			$xml = 'index' === $v ? self::build_index() : self::build_urlset( $v, $page );
			set_transient( $key, $xml, HOUR_IN_SECONDS );
		}
		status_header( 200 );
		header( 'Content-Type: application/xml; charset=UTF-8' );
		header( 'X-Robots-Tag: noindex, follow' );
		echo $xml; // phpcs:ignore WordPress.Security.EscapeOutput -- escaped when built
		exit;
	}

	private static function build_index() {
		$x = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( array_merge( [ WPAML_Languages::default_lang() ], WPAML_Languages::targets() ) as $lang ) {
			$q = new WP_Query( self::query_args( $lang ) + [ 'posts_per_page' => 1 ] );
			if ( ! $q->found_posts ) continue;
			for ( $p = 1, $n = (int) ceil( $q->found_posts / self::PER ); $p <= $n; $p++ ) {
				$x .= '<sitemap><loc>' . esc_xml( esc_url_raw( self::url( $lang, $p ) ) ) . "</loc></sitemap>\n";
			}
		}
		return $x . '</sitemapindex>';
	}

	private static function build_urlset( $lang, $page ) {
		$q = new WP_Query( self::query_args( $lang ) + [ 'posts_per_page' => self::PER, 'paged' => $page, 'no_found_rows' => true ] );
		$x = '<?xml version="1.0" encoding="UTF-8"?>' . "\n" . '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">' . "\n";
		foreach ( $q->posts as $id ) {
			$x .= '<url><loc>' . esc_xml( esc_url_raw( get_permalink( $id ) ) ) . '</loc><lastmod>' . esc_xml( get_post_modified_time( 'c', true, $id ) ) . '</lastmod>';
			$group = WPAML_T::published_group( $id );
			if ( count( $group ) > 1 ) {
				foreach ( $group as $l => $p ) {
					$x .= '<xhtml:link rel="alternate" hreflang="' . esc_attr( WPAML_Languages::hreflang( $l ) ) . '" href="' . esc_xml( esc_url_raw( get_permalink( $p ) ) ) . '"/>';
				}
				$d = WPAML_Languages::default_lang();
				if ( isset( $group[ $d ] ) ) $x .= '<xhtml:link rel="alternate" hreflang="x-default" href="' . esc_xml( esc_url_raw( get_permalink( $group[ $d ] ) ) ) . '"/>';
			}
			$x .= "</url>\n";
		}
		return $x . '</urlset>';
	}
}
