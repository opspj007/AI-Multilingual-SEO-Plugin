<?php
defined( 'ABSPATH' ) || exit;

class WPAML_Settings {
	const OPT = 'wpaml_settings';

	static function defaults() {
		$l = strtolower( substr( get_locale(), 0, 2 ) );
		return [
			'default_lang'  => isset( WPAML_Languages::all()[ $l ] ) ? $l : 'en',
			'targets'       => [],
			'post_types'    => [ 'post', 'page' ],
			'provider'      => 'anthropic', // anthropic | openai (any OpenAI-compatible endpoint)
			'api_key'       => '',
			'model'         => '',
			'base_url'      => 'https://api.openai.com/v1',
			'tone'          => 'Professional, clear and natural for a marketing audience.',
			'glossary'      => '',
			'dnt'           => '',
			'hreflang'      => 1,
			'auto_publish'  => 0,
			'remember_lang' => 0,
		];
	}

	static function get( $key = null ) {
		$o = wp_parse_args( (array) get_option( self::OPT, [] ), self::defaults() );
		return null === $key ? $o : ( $o[ $key ] ?? null );
	}

	static function init() {
		add_action( 'admin_init', function () {
			register_setting( 'wpaml', self::OPT, [ 'sanitize_callback' => [ __CLASS__, 'sanitize' ] ] );
		} );
	}

	static function sanitize( $in ) {
		$old = self::get();
		$in  = (array) $in;
		$all = WPAML_Languages::all();
		$out = [];
		$out['default_lang'] = isset( $all[ $in['default_lang'] ?? '' ] ) ? $in['default_lang'] : $old['default_lang'];
		$out['targets']      = array_values( array_diff( array_intersect( (array) ( $in['targets'] ?? [] ), array_keys( $all ) ), [ $out['default_lang'] ] ) );
		$out['post_types']   = array_values( array_intersect( array_map( 'sanitize_key', (array) ( $in['post_types'] ?? [] ) ), get_post_types( [ 'public' => true ] ) ) );
		$out['provider']     = ( $in['provider'] ?? '' ) === 'openai' ? 'openai' : 'anthropic';
		$key                 = trim( sanitize_text_field( $in['api_key'] ?? '' ) );
		$out['api_key']      = '' !== $key ? $key : $old['api_key']; // blank keeps the saved key
		$out['model']        = sanitize_text_field( $in['model'] ?? '' );
		$out['base_url']     = esc_url_raw( $in['base_url'] ?? $old['base_url'] );
		$out['tone']         = sanitize_text_field( $in['tone'] ?? '' );
		$out['glossary']     = sanitize_textarea_field( $in['glossary'] ?? '' );
		$out['dnt']          = sanitize_text_field( $in['dnt'] ?? '' );
		foreach ( [ 'hreflang', 'auto_publish', 'remember_lang' ] as $b ) {
			$out[ $b ] = empty( $in[ $b ] ) ? 0 : 1;
		}
		return $out;
	}
}
