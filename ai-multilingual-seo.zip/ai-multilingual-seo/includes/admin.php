<?php
defined( 'ABSPATH' ) || exit;

class WPAML_Admin {

	static function init() {
		add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
		add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
		add_action( 'admin_notices', [ __CLASS__, 'notices' ] );
		add_action( 'wp_ajax_wpaml_translate', [ __CLASS__, 'ajax_translate' ] );
		add_action( 'admin_post_wpaml_review', [ __CLASS__, 'do_review' ] );
		add_action( 'admin_post_wpaml_bulk_approve', [ __CLASS__, 'do_bulk_approve' ] );
		add_action( 'add_meta_boxes', [ __CLASS__, 'boxes' ] );
		add_action( 'save_post', [ __CLASS__, 'save_seo_box' ] );
		add_action( 'admin_init', [ __CLASS__, 'columns_init' ] );
		add_action( 'pre_get_posts', [ __CLASS__, 'filter_list' ] );
		add_action( 'restrict_manage_posts', [ __CLASS__, 'list_dropdown' ] );
	}

	/* ------------------------------------------------------------ helpers */

	static function review_url( $id ) { return admin_url( 'admin.php?page=wpaml-review&post=' . (int) $id ); }

	static function badge( $status, $outdated = false ) {
		$labels = WPAML_T::statuses();
		$h = '<span class="wpaml-badge wpaml-st-' . esc_attr( $status ?: 'pending' ) . '">' . esc_html( $labels[ $status ] ?? 'Unknown' ) . '</span>';
		if ( $outdated && in_array( $status, [ 'review', 'approved' ], true ) ) $h .= ' <span class="wpaml-badge wpaml-st-outdated" title="The source changed after this translation was made">Source changed</span>';
		return $h;
	}

	static function menu() {
		add_menu_page( 'AI Multilingual SEO', 'Multilingual SEO', 'edit_others_posts', 'wpaml', [ __CLASS__, 'page_dashboard' ], 'dashicons-translation', 59 );
		add_submenu_page( 'wpaml', 'Translations', 'Translations', 'edit_others_posts', 'wpaml', [ __CLASS__, 'page_dashboard' ] );
		add_submenu_page( 'wpaml', 'Bulk translate', 'Bulk translate', 'edit_others_posts', 'wpaml-bulk', [ __CLASS__, 'page_bulk' ] );
		add_submenu_page( 'wpaml', 'Settings', 'Settings', 'manage_options', 'wpaml-settings', [ __CLASS__, 'page_settings' ] );
		add_submenu_page( 'options.php', 'Review translation', 'Review', 'edit_others_posts', 'wpaml-review', [ __CLASS__, 'page_review' ] );
	}

	static function assets( $hook ) {
		$screen = get_current_screen();
		if ( ! $screen || ( false === strpos( $screen->id, 'wpaml' ) && ! in_array( $screen->base, [ 'post', 'edit' ], true ) ) ) return;
		wp_enqueue_style( 'wpaml-admin', WPAML_URL . 'assets/admin.css', [], WPAML_VERSION );
		wp_enqueue_script( 'wpaml-admin', WPAML_URL . 'assets/admin.js', [ 'jquery' ], WPAML_VERSION, true );
		wp_localize_script( 'wpaml-admin', 'WPAML', [
			'ajax'  => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'wpaml' ),
			'i18n'  => [
				'working' => 'Translating… (can take up to a minute)',
				'confirm' => 'This will overwrite the current translation and take it offline until you approve it again. Continue?',
				'done'    => 'Done',
				'error'   => 'Error',
			],
		] );
	}

	static function notices() {
		$s = get_current_screen();
		if ( ! $s || false === strpos( $s->id, 'wpaml' ) || false !== strpos( $s->id, 'settings' ) ) return;
		$link = ' <a href="' . esc_url( admin_url( 'admin.php?page=wpaml-settings' ) ) . '">Open settings</a>';
		if ( ! WPAML_Languages::targets() ) echo '<div class="notice notice-warning"><p>No target languages are enabled yet.' . $link . '</p></div>'; // phpcs:ignore
		if ( ! WPAML_AI::configured() ) echo '<div class="notice notice-warning"><p>No AI API key configured — you can still create blank drafts and translate manually.' . $link . '</p></div>'; // phpcs:ignore
		if ( ! empty( $_GET['wpaml_msg'] ) ) echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['wpaml_msg'] ) ) ) . '</p></div>';
	}

	/* ------------------------------------------------------------ ajax */

	static function ajax_translate() {
		check_ajax_referer( 'wpaml', 'nonce' );
		$sid  = (int) ( $_POST['post_id'] ?? 0 );
		$lang = strtolower( sanitize_text_field( wp_unslash( $_POST['lang'] ?? '' ) ) );
		if ( ! $sid || ! current_user_can( 'edit_post', $sid ) ) wp_send_json_error( [ 'message' => 'Permission denied.' ], 403 );
		if ( function_exists( 'set_time_limit' ) ) @set_time_limit( 300 ); // phpcs:ignore
		$r = ( ( $_POST['mode'] ?? 'ai' ) === 'blank' )
			? WPAML_T::create( $sid, $lang )
			: WPAML_Translator::run( $sid, $lang, ! empty( $_POST['force'] ) );
		if ( is_wp_error( $r ) ) wp_send_json_error( [ 'message' => $r->get_error_message() ] );
		wp_send_json_success( [ 'id' => $r, 'review' => self::review_url( $r ) ] );
	}

	/* ------------------------------------------------------------ dashboard */

	static function page_dashboard() {
		global $wpdb;
		$lang   = isset( $_GET['lang'] ) ? sanitize_text_field( wp_unslash( $_GET['lang'] ) ) : '';
		$status = isset( $_GET['status'] ) ? sanitize_key( $_GET['status'] ) : '';
		$paged  = max( 1, (int) ( $_GET['paged'] ?? 1 ) );

		$counts = [];
		foreach ( (array) $wpdb->get_results( "SELECT meta_value s, COUNT(*) c FROM {$wpdb->postmeta} WHERE meta_key='_wpaml_status' GROUP BY meta_value" ) as $r ) $counts[ $r->s ] = (int) $r->c;

		$mq = [ [ 'key' => '_wpaml_lang', 'compare' => 'EXISTS' ] ];
		if ( $lang && WPAML_Languages::is_target( $lang ) ) $mq[] = [ 'key' => '_wpaml_lang', 'value' => $lang ];
		if ( $status && isset( WPAML_T::statuses()[ $status ] ) ) $mq[] = [ 'key' => '_wpaml_status', 'value' => $status ];
		$q = new WP_Query( [
			'post_type' => WPAML_T::enabled_types() ?: [ 'post' ], 'post_status' => [ 'publish', 'draft', 'pending', 'private', 'future' ],
			'posts_per_page' => 30, 'paged' => $paged, 'orderby' => 'modified', 'order' => 'DESC', 'meta_query' => $mq, 'wpaml_skip' => true,
		] );
		?>
		<div class="wrap"><h1>Translations</h1>
		<ul class="subsubsub"><?php
			$links = [];
			foreach ( WPAML_T::statuses() as $k => $label ) {
				$links[] = '<li><a href="' . esc_url( add_query_arg( [ 'page' => 'wpaml', 'status' => $k ], admin_url( 'admin.php' ) ) ) . '" class="' . ( $status === $k ? 'current' : '' ) . '">' . esc_html( $label ) . ' <span class="count">(' . (int) ( $counts[ $k ] ?? 0 ) . ')</span></a>';
			}
			echo implode( ' | </li>', $links ) . '</li>'; // phpcs:ignore
		?></ul>
		<form method="get" style="margin:8px 0"><input type="hidden" name="page" value="wpaml">
			<select name="lang"><option value="">All languages</option><?php foreach ( WPAML_Languages::targets() as $l ) echo '<option value="' . esc_attr( $l ) . '"' . selected( $lang, $l, false ) . '>' . esc_html( WPAML_Languages::name( $l ) ) . '</option>'; ?></select>
			<select name="status"><option value="">All statuses</option><?php foreach ( WPAML_T::statuses() as $k => $v ) echo '<option value="' . esc_attr( $k ) . '"' . selected( $status, $k, false ) . '>' . esc_html( $v ) . '</option>'; ?></select>
			<button class="button">Filter</button></form>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'wpaml_bulk_approve' ); ?><input type="hidden" name="action" value="wpaml_bulk_approve">
		<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" onclick="jQuery('.wpaml-cb').prop('checked',this.checked)"></td><th>Translation</th><th>Language</th><th>Status</th><th>SEO check</th><th>Updated</th><th></th></tr></thead><tbody>
		<?php foreach ( $q->posts as $p ) :
			$st = WPAML_T::status( $p->ID ); $lg = WPAML_T::lang( $p->ID ); $src = get_post( WPAML_T::source_id( $p->ID ) ); $issues = WPAML_SEO::audit( $p->ID ); ?>
			<tr>
				<th class="check-column"><input type="checkbox" class="wpaml-cb" name="ids[]" value="<?php echo (int) $p->ID; ?>"></th>
				<td><strong><a href="<?php echo esc_url( self::review_url( $p->ID ) ); ?>"><?php echo esc_html( $p->post_title ?: '(no title)' ); ?></a></strong><br><small>Source: <?php echo esc_html( $src ? $src->post_title : '—' ); ?> · <?php echo esc_html( $p->post_type ); ?></small></td>
				<td><?php echo esc_html( WPAML_Languages::name( $lg ) ); ?></td>
				<td><?php echo self::badge( $st, WPAML_T::outdated( $p->ID ) ); // phpcs:ignore ?><?php if ( get_post_meta( $p->ID, '_wpaml_warning', true ) ) echo ' <span class="wpaml-badge wpaml-st-rejected" title="' . esc_attr( get_post_meta( $p->ID, '_wpaml_warning', true ) ) . '">Check structure</span>'; // phpcs:ignore ?></td>
				<td><?php echo $issues ? '<span class="wpaml-warn" title="' . esc_attr( implode( '; ', $issues ) ) . '">⚠ ' . count( $issues ) . '</span>' : '<span class="wpaml-ok">✓</span>'; // phpcs:ignore ?></td>
				<td><?php echo esc_html( get_the_modified_date( '', $p ) ); ?></td>
				<td><a class="button button-small" href="<?php echo esc_url( self::review_url( $p->ID ) ); ?>">Review</a> <a class="button button-small" href="<?php echo esc_url( get_edit_post_link( $p->ID ) ); ?>">Edit</a></td>
			</tr>
		<?php endforeach; if ( ! $q->posts ) echo '<tr><td colspan="7">No translations yet. Open a post and use the “Translations” box, or use Bulk translate.</td></tr>'; ?>
		</tbody></table>
		<p><button class="button button-primary" onclick="return confirm('Approve and publish the selected translations?')">Approve selected</button></p></form>
		<?php echo wp_kses_post( paginate_links( [ 'base' => add_query_arg( 'paged', '%#%' ), 'format' => '', 'current' => $paged, 'total' => $q->max_num_pages ] ) ); ?>
		</div>
		<?php
	}

	static function do_bulk_approve() {
		check_admin_referer( 'wpaml_bulk_approve' );
		$n = 0;
		foreach ( array_map( 'intval', (array) ( $_POST['ids'] ?? [] ) ) as $id ) {
			if ( WPAML_T::is_translation( $id ) && current_user_can( 'publish_post', $id ) ) { WPAML_T::approve( $id, get_current_user_id() ); $n++; }
		}
		wp_safe_redirect( add_query_arg( [ 'page' => 'wpaml', 'wpaml_msg' => rawurlencode( "$n translation(s) approved." ) ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ------------------------------------------------------------ bulk translate */

	static function page_bulk() {
		$types = WPAML_T::enabled_types();
		$type  = isset( $_GET['type'] ) && in_array( $_GET['type'], $types, true ) ? sanitize_key( $_GET['type'] ) : ( $types[0] ?? 'post' );
		$langs = WPAML_Languages::targets();
		$q     = new WP_Query( [ 'post_type' => $type, 'post_status' => 'publish', 'posts_per_page' => 100, 'orderby' => 'date', 'order' => 'DESC', 'wpaml_skip' => true, 'meta_query' => [ [ 'key' => '_wpaml_lang', 'compare' => 'NOT EXISTS' ] ] ] );
		?>
		<div class="wrap"><h1>Bulk translate</h1>
		<form method="get"><input type="hidden" name="page" value="wpaml-bulk"><select name="type"><?php foreach ( $types as $t ) echo '<option value="' . esc_attr( $t ) . '"' . selected( $type, $t, false ) . '>' . esc_html( get_post_type_object( $t )->labels->name ) . '</option>'; ?></select> <button class="button">Show</button></form>
		<p><strong>Languages:</strong> <?php foreach ( $langs as $l ) echo '<label style="margin-right:12px"><input type="checkbox" class="wpaml-lang" value="' . esc_attr( $l ) . '" checked> ' . esc_html( WPAML_Languages::name( $l ) ) . '</label>'; ?></p>
		<table class="widefat striped"><thead><tr><td class="check-column"><input type="checkbox" onclick="jQuery('.wpaml-post').prop('checked',this.checked)"></td><th>Title</th><?php foreach ( $langs as $l ) echo '<th>' . esc_html( strtoupper( $l ) ) . '</th>'; ?></tr></thead><tbody>
		<?php foreach ( $q->posts as $p ) : $tr = WPAML_T::translations( $p->ID ); ?>
			<tr><th class="check-column"><input type="checkbox" class="wpaml-post" value="<?php echo (int) $p->ID; ?>"></th><td><?php echo esc_html( $p->post_title ); ?></td>
			<?php foreach ( $langs as $l ) echo '<td>' . ( isset( $tr[ $l ] ) ? self::badge( WPAML_T::status( $tr[ $l ]->ID ) ) : '—' ) . '</td>'; // phpcs:ignore ?></tr>
		<?php endforeach; ?>
		</tbody></table>
		<p><label><input type="checkbox" id="wpaml-skip-existing" checked> Skip languages that already have a translation</label></p>
		<p><button class="button button-primary" id="wpaml-bulk-run" <?php disabled( ! WPAML_AI::configured() ); ?>>Translate selected with AI</button></p>
		<ol id="wpaml-log"></ol></div>
		<?php
	}

	/* ------------------------------------------------------------ review */

	static function page_review() {
		$id = (int) ( $_GET['post'] ?? 0 );
		$tr = get_post( $id );
		if ( ! $tr || ! WPAML_T::is_translation( $id ) || ! current_user_can( 'edit_post', $id ) ) wp_die( 'Translation not found.' );
		$sid  = WPAML_T::source_id( $id );
		$src  = get_post( $sid );
		$lang = WPAML_T::lang( $id );
		$ss   = WPAML_SEO::read( $sid );
		$ts   = WPAML_SEO::read( $id );
		$st   = WPAML_T::status( $id );
		$row  = function ( $label, $name, $sv, $tv, $type = 'input', $max = 0 ) {
			echo '<tr><th>' . esc_html( $label ) . '</th><td class="wpaml-src"><div class="wpaml-ro">' . ( '' === $sv ? '<em>—</em>' : nl2br( esc_html( $sv ) ) ) . '</div></td><td>';
			if ( 'textarea' === $type ) echo '<textarea name="' . esc_attr( $name ) . '" rows="' . ( 'content' === $name ? 18 : 3 ) . '" class="large-text code"' . ( $max ? ' data-max="' . (int) $max . '"' : '' ) . '>' . esc_textarea( $tv ) . '</textarea>';
			else echo '<input type="text" name="' . esc_attr( $name ) . '" value="' . esc_attr( $tv ) . '" class="large-text"' . ( $max ? ' data-max="' . (int) $max . '"' : '' ) . '>';
			echo $max ? '<span class="wpaml-count"></span>' : '';
			echo '</td></tr>';
		};
		?>
		<div class="wrap"><h1>Review: <?php echo esc_html( WPAML_Languages::name( $lang ) ); ?> translation</h1>
		<p><?php echo self::badge( $st, WPAML_T::outdated( $id ) ); // phpcs:ignore ?>
		 · <a href="<?php echo esc_url( get_edit_post_link( $sid ) ); ?>">Edit source</a> · <a href="<?php echo esc_url( get_edit_post_link( $id ) ); ?>">Open in editor</a><?php if ( 'publish' === $tr->post_status ) echo ' · <a href="' . esc_url( get_permalink( $id ) ) . '" target="_blank">View live</a>'; // phpcs:ignore ?>
		 <?php if ( $m = get_post_meta( $id, '_wpaml_ai_model', true ) ) echo '· <small>AI: ' . esc_html( $m ) . '</small>'; ?></p>
		<?php if ( $w = get_post_meta( $id, '_wpaml_warning', true ) ) echo '<div class="notice notice-warning inline"><p>' . esc_html( $w ) . '</p></div>'; ?>
		<?php if ( $n = get_post_meta( $id, '_wpaml_note', true ) ) echo '<div class="notice notice-error inline"><p><strong>Rejection note:</strong> ' . esc_html( $n ) . '</p></div>'; ?>
		<?php if ( WPAML_T::outdated( $id ) && in_array( $st, [ 'review', 'approved' ], true ) ) echo '<div class="notice notice-info inline"><p>The source content or SEO changed after this translation was made. Re-translate with AI, or update by hand and approve to mark it current.</p></div>'; ?>

		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
		<?php wp_nonce_field( 'wpaml_review_' . $id ); ?><input type="hidden" name="action" value="wpaml_review"><input type="hidden" name="post_id" value="<?php echo (int) $id; ?>">
		<table class="widefat wpaml-review"><thead><tr><th style="width:120px"></th><th>Source (<?php echo esc_html( WPAML_Languages::name( WPAML_Languages::default_lang() ) ); ?>)</th><th>Translation (<?php echo esc_html( WPAML_Languages::name( $lang ) ); ?>)</th></tr></thead><tbody>
		<?php
		$row( 'Title', 'title', $src->post_title, $tr->post_title );
		$row( 'URL slug', 'slug', $src->post_name, $tr->post_name );
		$row( 'SEO title', 'seo_title', $ss['title'], $ts['title'], 'input', 60 );
		$row( 'Meta description', 'seo_desc', $ss['desc'], $ts['desc'], 'textarea', 160 );
		$row( 'Focus keyword', 'seo_kw', $ss['kw'], $ts['kw'] );
		$row( 'Excerpt', 'excerpt', $src->post_excerpt, $tr->post_excerpt, 'textarea' );
		$row( 'Content', 'content', $src->post_content, $tr->post_content, 'textarea' );
		?></tbody></table>
		<p><label>Rejection note (only used when rejecting)<br><input type="text" name="note" class="large-text" value=""></label></p>
		<p class="submit">
			<button name="do" value="save" class="button">Save draft</button>
			<button name="do" value="approve" class="button button-primary">Approve &amp; publish</button>
			<button name="do" value="reject" class="button">Reject</button>
			<?php if ( WPAML_AI::configured() ) : ?><button type="button" class="button wpaml-translate" data-post="<?php echo (int) $sid; ?>" data-lang="<?php echo esc_attr( $lang ); ?>" data-force="1">Re-translate with AI</button><?php endif; ?>
		</p></form></div>
		<?php
	}

	static function do_review() {
		$id = (int) ( $_POST['post_id'] ?? 0 );
		check_admin_referer( 'wpaml_review_' . $id );
		if ( ! WPAML_T::is_translation( $id ) || ! current_user_can( 'edit_post', $id ) ) wp_die( 'Forbidden', 403 );
		$g = function ( $k ) { return wp_unslash( $_POST[ $k ] ?? '' ); };
		WPAML_T::apply_fields( $id, [
			'title'   => sanitize_text_field( $g( 'title' ) ),
			'slug'    => $g( 'slug' ),
			'content' => $g( 'content' ),
			'excerpt' => $g( 'excerpt' ),
			'seo'     => [ 'title' => $g( 'seo_title' ), 'desc' => $g( 'seo_desc' ), 'kw' => $g( 'seo_kw' ) ],
		] );
		$do  = sanitize_key( $_POST['do'] ?? 'save' );
		$msg = 'Draft saved.';
		if ( 'approve' === $do ) {
			if ( ! current_user_can( 'publish_post', $id ) ) wp_die( 'Forbidden', 403 );
			WPAML_T::approve( $id, get_current_user_id() );
			$msg = 'Approved.';
		} elseif ( 'reject' === $do ) {
			WPAML_T::reject( $id, $g( 'note' ) );
			$msg = 'Rejected.';
		} elseif ( 'pending' === WPAML_T::status( $id ) ) {
			update_post_meta( $id, '_wpaml_status', 'review' );
			update_post_meta( $id, '_wpaml_source_hash', WPAML_T::source_hash( WPAML_T::source_id( $id ) ) );
		}
		wp_safe_redirect( add_query_arg( [ 'page' => 'wpaml-review', 'post' => $id, 'wpaml_msg' => rawurlencode( $msg ) ], admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ------------------------------------------------------------ settings */

	static function page_settings() {
		$o = WPAML_Settings::get();
		$n = WPAML_Settings::OPT;
		$f = function ( $k ) use ( $n ) { return esc_attr( $n . '[' . $k . ']' ); };
		?>
		<div class="wrap"><h1>Multilingual SEO settings</h1>
		<form method="post" action="options.php"><?php settings_fields( 'wpaml' ); ?>
		<h2>Languages</h2><table class="form-table">
		<tr><th>Original (default) language</th><td><select name="<?php echo $f( 'default_lang' ); // phpcs:ignore ?>"><?php foreach ( WPAML_Languages::all() as $c => $l ) echo '<option value="' . esc_attr( $c ) . '"' . selected( $o['default_lang'], $c, false ) . '>' . esc_html( $l[0] ) . '</option>'; ?></select></td></tr>
		<tr><th>Translate into</th><td class="wpaml-grid"><?php foreach ( WPAML_Languages::all() as $c => $l ) echo '<label><input type="checkbox" name="' . $f( 'targets' ) . '[]" value="' . esc_attr( $c ) . '"' . checked( in_array( $c, (array) $o['targets'], true ), true, false ) . '> ' . esc_html( $l[0] ) . '</label>'; // phpcs:ignore ?></td></tr>
		<tr><th>Content types</th><td><?php foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) { if ( 'attachment' === $pt->name ) continue; echo '<label style="margin-right:14px"><input type="checkbox" name="' . $f( 'post_types' ) . '[]" value="' . esc_attr( $pt->name ) . '"' . checked( in_array( $pt->name, (array) $o['post_types'], true ), true, false ) . '> ' . esc_html( $pt->labels->name ) . '</label>'; } // phpcs:ignore
			if ( class_exists( 'WooCommerce' ) ) echo '<p class="description">WooCommerce detected — enable “Products”. Variable products are not supported yet.</p>'; ?></td></tr>
		</table>
		<h2>AI provider</h2><table class="form-table">
		<tr><th>Provider</th><td><select name="<?php echo $f( 'provider' ); // phpcs:ignore ?>"><option value="anthropic" <?php selected( $o['provider'], 'anthropic' ); ?>>Anthropic (Claude)</option><option value="openai" <?php selected( $o['provider'], 'openai' ); ?>>OpenAI-compatible</option></select></td></tr>
		<tr><th>API key</th><td><input type="password" class="regular-text" name="<?php echo $f( 'api_key' ); // phpcs:ignore ?>" autocomplete="off" placeholder="<?php echo $o['api_key'] ? '•••••• saved (leave blank to keep)' : ''; ?>"><p class="description">Or define <code>WPAML_API_KEY</code> in wp-config.php (recommended).</p></td></tr>
		<tr><th>Model</th><td><input type="text" class="regular-text" name="<?php echo $f( 'model' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $o['model'] ); ?>" placeholder="<?php echo esc_attr( WPAML_AI::model() ); ?>"></td></tr>
		<tr><th>Base URL <small>(OpenAI-compatible only)</small></th><td><input type="url" class="regular-text" name="<?php echo $f( 'base_url' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $o['base_url'] ); ?>"></td></tr>
		</table>
		<h2>Translation style</h2><table class="form-table">
		<tr><th>Tone &amp; style</th><td><input type="text" class="large-text" name="<?php echo $f( 'tone' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $o['tone'] ); ?>"></td></tr>
		<tr><th>Do-not-translate terms</th><td><input type="text" class="large-text" name="<?php echo $f( 'dnt' ); // phpcs:ignore ?>" value="<?php echo esc_attr( $o['dnt'] ); ?>" placeholder="Acme Cloud, FlowPro"><p class="description">Comma-separated brand and product names.</p></td></tr>
		<tr><th>Glossary</th><td><textarea class="large-text code" rows="5" name="<?php echo $f( 'glossary' ); // phpcs:ignore ?>" placeholder="checkout = finalizar compra&#10;de: shopping cart = Warenkorb"><?php echo esc_textarea( $o['glossary'] ); ?></textarea><p class="description">One per line: <code>term = translation</code>. Prefix with a language code and colon to scope it (<code>de: …</code>).</p></td></tr>
		</table>
		<h2>Publishing &amp; SEO</h2><table class="form-table">
		<tr><th>Approval</th><td><label><input type="checkbox" name="<?php echo $f( 'auto_publish' ); // phpcs:ignore ?>" value="1" <?php checked( $o['auto_publish'], 1 ); ?>> Publish AI translations automatically (skips human review — not recommended)</label></td></tr>
		<tr><th>hreflang tags</th><td><label><input type="checkbox" name="<?php echo $f( 'hreflang' ); // phpcs:ignore ?>" value="1" <?php checked( $o['hreflang'], 1 ); ?>> Output hreflang alternates and x-default</label></td></tr>
		<tr><th>Remember language</th><td><label><input type="checkbox" name="<?php echo $f( 'remember_lang' ); // phpcs:ignore ?>" value="1" <?php checked( $o['remember_lang'], 1 ); ?>> Use a cookie so shop/blog archives follow the visitor’s language <small>(can conflict with full-page caching)</small></label></td></tr>
		<tr><th>SEO plugin</th><td>Detected: <strong><?php echo esc_html( [ 'yoast' => 'Yoast SEO', 'rankmath' => 'Rank Math', 'own' => 'none — this plugin outputs title, description and Open Graph tags' ][ WPAML_SEO::engine() ] ); ?></strong></td></tr>
		<tr><th>Sitemaps</th><td><a href="<?php echo esc_url( WPAML_Sitemap::url() ); ?>" target="_blank"><?php echo esc_html( WPAML_Sitemap::url() ); ?></a><p class="description">Added to robots.txt automatically. If you use Yoast/Rank Math, submit this index too and exclude translations from their sitemaps.</p></td></tr>
		</table>
		<?php submit_button(); ?></form></div>
		<?php
	}

	/* ------------------------------------------------------------ metaboxes */

	static function boxes() {
		foreach ( WPAML_T::enabled_types() as $pt ) {
			add_meta_box( 'wpaml_tr', 'Translations', [ __CLASS__, 'box_translations' ], $pt, 'side' );
			if ( 'own' === WPAML_SEO::engine() ) add_meta_box( 'wpaml_seo', 'SEO title & description', [ __CLASS__, 'box_seo' ], $pt, 'normal' );
		}
	}

	static function box_translations( $post ) {
		if ( 'auto-draft' === $post->post_status ) { echo '<p>Save the post first.</p>'; return; }
		if ( WPAML_T::is_translation( $post->ID ) ) {
			$sid = WPAML_T::source_id( $post->ID );
			echo '<p>' . esc_html( WPAML_Languages::name( WPAML_T::lang( $post->ID ) ) ) . ' translation of <a href="' . esc_url( get_edit_post_link( $sid ) ) . '">' . esc_html( get_the_title( $sid ) ) . '</a></p><p>' . self::badge( WPAML_T::status( $post->ID ), WPAML_T::outdated( $post->ID ) ) . '</p><p><a class="button" href="' . esc_url( self::review_url( $post->ID ) ) . '">Open review screen</a></p>'; // phpcs:ignore
			return;
		}
		$tr = WPAML_T::translations( $post->ID );
		if ( ! WPAML_Languages::targets() ) { echo '<p>No target languages enabled.</p>'; return; }
		foreach ( WPAML_Languages::targets() as $l ) {
			echo '<div class="wpaml-lang-row"><strong>' . esc_html( WPAML_Languages::name( $l ) ) . '</strong><br>';
			if ( isset( $tr[ $l ] ) ) {
				echo self::badge( WPAML_T::status( $tr[ $l ]->ID ), WPAML_T::outdated( $tr[ $l ]->ID ) ) . ' <a href="' . esc_url( self::review_url( $tr[ $l ]->ID ) ) . '">Review</a>'; // phpcs:ignore
				if ( WPAML_AI::configured() ) echo ' · <a href="#" class="wpaml-translate" data-post="' . (int) $post->ID . '" data-lang="' . esc_attr( $l ) . '" data-force="1">Re-translate</a>';
			} else {
				if ( WPAML_AI::configured() ) echo '<button type="button" class="button button-small wpaml-translate" data-post="' . (int) $post->ID . '" data-lang="' . esc_attr( $l ) . '">Translate with AI</button> ';
				echo '<button type="button" class="button button-small wpaml-translate" data-mode="blank" data-post="' . (int) $post->ID . '" data-lang="' . esc_attr( $l ) . '">Blank draft</button>';
			}
			echo '</div>';
		}
	}

	static function box_seo( $post ) {
		wp_nonce_field( 'wpaml_seo', 'wpaml_seo_nonce' );
		$s = WPAML_SEO::read( $post->ID );
		echo '<p><label>SEO title<br><input type="text" class="large-text" name="wpaml_seo_title" value="' . esc_attr( $s['title'] ) . '" data-max="60"><span class="wpaml-count"></span></label></p>';
		echo '<p><label>Meta description<br><textarea class="large-text" rows="3" name="wpaml_seo_desc" data-max="160">' . esc_textarea( $s['desc'] ) . '</textarea><span class="wpaml-count"></span></label></p>';
		echo '<p><label>Focus keyword<br><input type="text" class="regular-text" name="wpaml_seo_kw" value="' . esc_attr( $s['kw'] ) . '"></label></p>';
	}

	static function save_seo_box( $post_id ) {
		if ( ! isset( $_POST['wpaml_seo_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['wpaml_seo_nonce'] ), 'wpaml_seo' ) ) return;
		if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) return;
		WPAML_SEO::write( $post_id, [
			'title' => wp_unslash( $_POST['wpaml_seo_title'] ?? '' ),
			'desc'  => wp_unslash( $_POST['wpaml_seo_desc'] ?? '' ),
			'kw'    => wp_unslash( $_POST['wpaml_seo_kw'] ?? '' ),
		] );
	}

	/* ------------------------------------------------------------ post list integration */

	static function columns_init() {
		foreach ( WPAML_T::enabled_types() as $pt ) {
			add_filter( "manage_{$pt}_posts_columns", function ( $c ) { $c['wpaml'] = 'Translations'; return $c; } );
			add_action( "manage_{$pt}_posts_custom_column", [ __CLASS__, 'column' ], 10, 2 );
		}
	}

	static function column( $col, $id ) {
		if ( 'wpaml' !== $col ) return;
		if ( WPAML_T::is_translation( $id ) ) { echo esc_html( strtoupper( WPAML_T::lang( $id ) ) ) . ' ← #' . (int) WPAML_T::source_id( $id ); return; }
		$tr = WPAML_T::translations( $id );
		foreach ( WPAML_Languages::targets() as $l ) {
			$st = isset( $tr[ $l ] ) ? WPAML_T::status( $tr[ $l ]->ID ) : 'none';
			$tag = '<span class="wpaml-chip wpaml-st-' . esc_attr( $st ) . '" title="' . esc_attr( WPAML_Languages::name( $l ) . ': ' . ( WPAML_T::statuses()[ $st ] ?? 'No translation' ) ) . '">' . esc_html( strtoupper( $l ) ) . '</span>';
			echo isset( $tr[ $l ] ) ? '<a href="' . esc_url( self::review_url( $tr[ $l ]->ID ) ) . '">' . $tag . '</a>' : $tag; // phpcs:ignore
		}
	}

	/** Admin lists show originals by default; ?wpaml_lang=xx or all shows translations. */
	static function filter_list( $q ) {
		global $pagenow;
		if ( ! is_admin() || ! $q->is_main_query() || 'edit.php' !== $pagenow || $q->get( 'wpaml_skip' ) ) return;
		$pt = $q->get( 'post_type' ) ?: 'post';
		if ( ! is_string( $pt ) || ! in_array( $pt, WPAML_T::enabled_types(), true ) ) return;
		$f = isset( $_GET['wpaml_lang'] ) ? sanitize_text_field( wp_unslash( $_GET['wpaml_lang'] ) ) : '';
		if ( 'all' === $f ) return;
		$mq   = (array) $q->get( 'meta_query' );
		$mq[] = ( '' === $f || WPAML_Languages::default_lang() === $f )
			? [ 'key' => '_wpaml_lang', 'compare' => 'NOT EXISTS' ]
			: [ 'key' => '_wpaml_lang', 'value' => $f ];
		$q->set( 'meta_query', $mq );
	}

	static function list_dropdown( $post_type ) {
		if ( ! in_array( $post_type, WPAML_T::enabled_types(), true ) ) return;
		$cur = isset( $_GET['wpaml_lang'] ) ? sanitize_text_field( wp_unslash( $_GET['wpaml_lang'] ) ) : '';
		echo '<select name="wpaml_lang"><option value="">Originals (' . esc_html( WPAML_Languages::name( WPAML_Languages::default_lang() ) ) . ')</option>';
		foreach ( WPAML_Languages::targets() as $l ) echo '<option value="' . esc_attr( $l ) . '"' . selected( $cur, $l, false ) . '>' . esc_html( WPAML_Languages::name( $l ) ) . '</option>';
		echo '<option value="all"' . selected( $cur, 'all', false ) . '>All languages</option></select>';
	}
}
