<?php
defined( 'ABSPATH' ) || exit;

class WPAML_Languages {

	/** code => [ English name, native name, locale, rtl ] */
	static function all() {
		return [
			'en'    => [ 'English', 'English', 'en_US', 0 ],
			'es'    => [ 'Spanish', 'Español', 'es_ES', 0 ],
			'fr'    => [ 'French', 'Français', 'fr_FR', 0 ],
			'de'    => [ 'German', 'Deutsch', 'de_DE', 0 ],
			'it'    => [ 'Italian', 'Italiano', 'it_IT', 0 ],
			'pt'    => [ 'Portuguese', 'Português', 'pt_PT', 0 ],
			'pt-br' => [ 'Portuguese (Brazil)', 'Português (Brasil)', 'pt_BR', 0 ],
			'nl'    => [ 'Dutch', 'Nederlands', 'nl_NL', 0 ],
			'pl'    => [ 'Polish', 'Polski', 'pl_PL', 0 ],
			'ru'    => [ 'Russian', 'Русский', 'ru_RU', 0 ],
			'uk'    => [ 'Ukrainian', 'Українська', 'uk_UA', 0 ],
			'tr'    => [ 'Turkish', 'Türkçe', 'tr_TR', 0 ],
			'ar'    => [ 'Arabic', 'العربية', 'ar', 1 ],
			'he'    => [ 'Hebrew', 'עברית', 'he_IL', 1 ],
			'fa'    => [ 'Persian', 'فارسی', 'fa_IR', 1 ],
			'ur'    => [ 'Urdu', 'اردو', 'ur', 1 ],
			'hi'    => [ 'Hindi', 'हिन्दी', 'hi_IN', 0 ],
			'bn'    => [ 'Bengali', 'বাংলা', 'bn_BD', 0 ],
			'ja'    => [ 'Japanese', '日本語', 'ja', 0 ],
			'ko'    => [ 'Korean', '한국어', 'ko_KR', 0 ],
			'zh-cn' => [ 'Chinese (Simplified)', '简体中文', 'zh_CN', 0 ],
			'zh-tw' => [ 'Chinese (Traditional)', '繁體中文', 'zh_TW', 0 ],
			'id'    => [ 'Indonesian', 'Bahasa Indonesia', 'id_ID', 0 ],
			'ms'    => [ 'Malay', 'Bahasa Melayu', 'ms_MY', 0 ],
			'vi'    => [ 'Vietnamese', 'Tiếng Việt', 'vi', 0 ],
			'th'    => [ 'Thai', 'ไทย', 'th', 0 ],
			'sv'    => [ 'Swedish', 'Svenska', 'sv_SE', 0 ],
			'da'    => [ 'Danish', 'Dansk', 'da_DK', 0 ],
			'no'    => [ 'Norwegian', 'Norsk', 'nb_NO', 0 ],
			'fi'    => [ 'Finnish', 'Suomi', 'fi', 0 ],
			'cs'    => [ 'Czech', 'Čeština', 'cs_CZ', 0 ],
			'el'    => [ 'Greek', 'Ελληνικά', 'el', 0 ],
			'ro'    => [ 'Romanian', 'Română', 'ro_RO', 0 ],
			'hu'    => [ 'Hungarian', 'Magyar', 'hu_HU', 0 ],
		];
	}

	static function default_lang() {
		$d = WPAML_Settings::get( 'default_lang' );
		return isset( self::all()[ $d ] ) ? $d : 'en';
	}

	/** Enabled target languages (never includes the default). */
	static function targets() {
		$all = self::all();
		$d   = self::default_lang();
		return array_values( array_filter( (array) WPAML_Settings::get( 'targets' ), function ( $c ) use ( $all, $d ) {
			return isset( $all[ $c ] ) && $c !== $d;
		} ) );
	}

	static function is_target( $c ) { return in_array( $c, self::targets(), true ); }
	static function is_enabled( $c ) { return $c === self::default_lang() || self::is_target( $c ); }
	static function name( $c ) { return self::all()[ $c ][0] ?? $c; }
	static function native( $c ) { return self::all()[ $c ][1] ?? $c; }
	static function locale( $c ) { return self::all()[ $c ][2] ?? 'en_US'; }
	static function rtl( $c ) { return ! empty( self::all()[ $c ][3] ); }

	/** BCP-47 tag for hreflang / lang attributes (pt-br -> pt-BR). */
	static function hreflang( $c ) {
		$p = explode( '-', $c );
		return 2 === count( $p ) ? $p[0] . '-' . strtoupper( $p[1] ) : $c;
	}
}
