<?php
defined( 'ABSPATH' ) || exit;

/** Front-end: per-language query filtering, language switcher, optional language memory. */
class WPAML_Front {

	static function init() {
		add_action( 'pre_get_posts', [ __CLASS__, 'filter_query' ] );
		add_action( 'template_redirect', [ __CLASS__, 'remember' ] );
		add_shortcode( 'wpaml_switcher', [ __CLASS__, 'switcher' ] );
		add_action( 'wp_enqueue_scripts', function () {
			wp_enqueue_style( 'wpaml-front', WPAML_URL . 'assets/front.css', [], WPAML_VERSION );
		} );
	}

	private static function enabled_singular_id() {
		if ( ! did_action( 'wp' ) || ! is_singular() ) return 0;
		$id = get_queried_object_id();
		return ( $id && in_array( get_post_type( $id ), WPAML_T::enabled_types(), true ) ) ? $id : 0;
	}

	/** Language of the current request: singular post > ?lang= > cookie (optional) > default. */
	static function current_lang() {
		if ( $id = self::enabled_singular_id() ) return WPAML_T::lang( $id );
		if ( ! empty( $_GET['lang'] ) ) {
			$l = strtolower( sanitize_text_field( wp_unslash( $_GET['lang'] ) ) );
			if ( WPAML_Languages::is_enabled( $l ) ) return $l;
		}
		if ( WPAML_Settings::get( 'remember_lang' ) && ! empty( $_COOKIE['wpaml_lang'] ) ) {
			$l = strtolower( sanitize_text_field( wp_unslash( $_COOKIE['wpaml_lang'] ) ) );
			if ( WPAML_Languages::is_enabled( $l ) ) return $l;
		}
		return WPAML_Languages::default_lang();
	}

	/** Lists/archives/search/shop only show posts in the current language. Single-post queries are untouched. */
	static function filter_query( $q ) {
		if ( is_admin() || wp_doing_ajax() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) || $q->get( 'wpaml_skip' ) ) return;
		if ( $q->is_singular() || $q->get( 'p' ) || $q->get( 'page_id' ) || $q->get( 'name' ) || $q->get( 'pagename' ) || $q->get( 'post__in' ) || $q->get( 'attachment' ) ) return;

		$pt = $q->get( 'post_type' );
		$pt = (array) ( $pt ?: 'post' );
		if ( ! in_array( 'any', $pt, true ) && ! array_intersect( $pt, WPAML_T::enabled_types() ) ) return;

		$lang = self::current_lang();
		$mq   = (array) $q->get( 'meta_query' );
		$mq[] = $lang === WPAML_Languages::default_lang()
			? [ 'key' => '_wpaml_lang', 'compare' => 'NOT EXISTS' ]
			: [ 'key' => '_wpaml_lang', 'value' => $lang ];
		$q->set( 'meta_query', $mq );
	}

	static function remember() {
		if ( ! WPAML_Settings::get( 'remember_lang' ) || headers_sent() ) return;
		$lang = null;
		if ( $id = self::enabled_singular_id() ) {
			$lang = WPAML_T::lang( $id );
		} elseif ( ! empty( $_GET['lang'] ) ) {
			$l = strtolower( sanitize_text_field( wp_unslash( $_GET['lang'] ) ) );
			if ( WPAML_Languages::is_enabled( $l ) ) $lang = $l;
		}
		if ( $lang ) {
			setcookie( 'wpaml_lang', $lang, time() + 30 * DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true );
			$_COOKIE['wpaml_lang'] = $lang;
		}
	}

	/** [wpaml_switcher style="list|dropdown" label="native|name|code"] */
	static function switcher( $atts = [] ) {
		$a     = shortcode_atts( [ 'style' => 'list', 'label' => 'native' ], $atts );
		$cur   = self::current_lang();
		$langs = array_merge( [ WPAML_Languages::default_lang() ], WPAML_Languages::targets() );
		$items = [];
		if ( $id = self::enabled_singular_id() ) {
			$group = WPAML_T::published_group( $id );
			foreach ( $langs as $l ) {
				if ( isset( $group[ $l ] ) ) $items[ $l ] = get_permalink( $group[ $l ] );
			}
		} else {
			foreach ( $langs as $l ) {
				$items[ $l ] = $l === WPAML_Languages::default_lang() ? remove_query_arg( 'lang' ) : add_query_arg( 'lang', $l );
			}
		}
		if ( count( $items ) < 2 ) return '';
		$label = function ( $l ) use ( $a ) {
			return 'code' === $a['label'] ? strtoupper( $l ) : ( 'name' === $a['label'] ? WPAML_Languages::name( $l ) : WPAML_Languages::native( $l ) );
		};
		if ( 'dropdown' === $a['style'] ) {
			$o = '<select class="wpaml-switcher wpaml-dropdown" aria-label="Language" onchange="window.location.href=this.value">';
			foreach ( $items as $l => $u ) $o .= '<option value="' . esc_url( $u ) . '"' . selected( $l, $cur, false ) . '>' . esc_html( $label( $l ) ) . '</option>';
			return $o . '</select>';
		}
		$o = '<ul class="wpaml-switcher">';
		foreach ( $items as $l => $u ) {
			$o .= '<li class="' . ( $l === $cur ? 'wpaml-current' : '' ) . '"><a href="' . esc_url( $u ) . '" hreflang="' . esc_attr( WPAML_Languages::hreflang( $l ) ) . '" lang="' . esc_attr( WPAML_Languages::hreflang( $l ) ) . '">' . esc_html( $label( $l ) ) . '</a></li>';
		}
		return $o . '</ul>';
	}
}

/** Template tag: echo wpaml_switcher(); */
function wpaml_switcher( $args = [] ) { return WPAML_Front::switcher( $args ); }

/** URL of a post's translation in $lang (or null). */
function wpaml_get_translation_url( $post_id, $lang ) {
	$g = WPAML_T::published_group( $post_id );
	return isset( $g[ $lang ] ) ? get_permalink( $g[ $lang ] ) : null;
}
