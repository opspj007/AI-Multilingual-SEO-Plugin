<?php
defined( 'ABSPATH' ) || exit;

/** Provider-agnostic AI client: Anthropic Messages API or any OpenAI-compatible chat/completions endpoint. */
class WPAML_AI {

	static function key() {
		return defined( 'WPAML_API_KEY' ) && WPAML_API_KEY ? WPAML_API_KEY : WPAML_Settings::get( 'api_key' );
	}

	static function configured() { return (bool) self::key(); }

	static function model() {
		$m = WPAML_Settings::get( 'model' );
		if ( $m ) return $m;
		return 'anthropic' === WPAML_Settings::get( 'provider' ) ? 'claude-sonnet-5-5' : 'gpt-4o';
	}

	/** Returns response text or WP_Error. Retries once on transient failures. */
	static function complete( $system, $user, $max_tokens = 4000 ) {
		$key = self::key();
		if ( ! $key ) return new WP_Error( 'noai', 'Add your AI API key under Multilingual SEO → Settings.' );
		$anthropic = 'anthropic' === WPAML_Settings::get( 'provider' );
		$err       = new WP_Error( 'ai', 'Unknown AI error.' );

		for ( $try = 0; $try < 2; $try++ ) {
			if ( $anthropic ) {
				$url     = 'https://api.anthropic.com/v1/messages';
				$headers = [ 'x-api-key' => $key, 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json' ];
				$body    = [ 'model' => self::model(), 'max_tokens' => $max_tokens, 'system' => $system, 'messages' => [ [ 'role' => 'user', 'content' => $user ] ] ];
			} else {
				$url     = rtrim( WPAML_Settings::get( 'base_url' ), '/' ) . '/chat/completions';
				$headers = [ 'Authorization' => 'Bearer ' . $key, 'Content-Type' => 'application/json' ];
				$body    = [ 'model' => self::model(), 'messages' => [ [ 'role' => 'system', 'content' => $system ], [ 'role' => 'user', 'content' => $user ] ] ];
			}
			$res = wp_remote_post( $url, [ 'timeout' => 180, 'headers' => $headers, 'body' => wp_json_encode( $body ) ] );
			if ( is_wp_error( $res ) ) {
				$err = $res;
			} else {
				$code = (int) wp_remote_retrieve_response_code( $res );
				$data = json_decode( wp_remote_retrieve_body( $res ), true );
				if ( $code >= 200 && $code < 300 ) {
					$text = '';
					if ( $anthropic ) {
						foreach ( (array) ( $data['content'] ?? [] ) as $b ) {
							if ( 'text' === ( $b['type'] ?? '' ) ) $text .= $b['text'];
						}
					} else {
						$text = (string) ( $data['choices'][0]['message']['content'] ?? '' );
					}
					if ( '' !== trim( $text ) ) return $text;
					$err = new WP_Error( 'empty', 'The AI provider returned an empty response.' );
				} else {
					$err = new WP_Error( 'ai_http', $data['error']['message'] ?? "AI provider error (HTTP $code)." );
					if ( ! in_array( $code, [ 408, 429, 500, 502, 503, 529 ], true ) ) return $err;
				}
			}
			if ( 0 === $try ) sleep( 2 );
		}
		return $err;
	}
}
