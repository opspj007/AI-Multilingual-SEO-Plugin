=== AI Multilingual SEO ===
Requires at least: 5.8
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later

Localize pages, products, SEO metadata and blog posts with AI-assisted translation, human review, hreflang and language-specific sitemaps. WooCommerce compatible.

== Setup ==
1. Settings: choose the original language, target languages and content types (enable Products for WooCommerce).
2. Add an AI key (Anthropic or any OpenAI-compatible API). Prefer `define('WPAML_API_KEY','...');` in wp-config.php.
3. Edit any post/page/product -> "Translations" box -> Translate with AI. Or use Bulk translate.
4. Review side-by-side (Multilingual SEO > Translations), edit, then Approve & publish.
5. Add [wpaml_switcher] (or style="dropdown") to a menu, widget or template. Submit /wpaml-sitemap.xml to search engines.

== How it works ==
Each translation is a normal post linked to its original; it has its own slug, SEO title, meta description and focus keyword.
Yoast SEO and Rank Math fields are read/written natively; without them the plugin outputs title, description and Open Graph tags itself.
hreflang + x-default are output for every post that has published translations. Sitemaps: /wpaml-sitemap.xml (index) and /wpaml-sitemap-{lang}.xml with xhtml:link alternates.

== Known limitations (v1) ==
* Page builders (Elementor, Divi) and WooCommerce variable products are blocked with a clear message.
* Categories, tags, menus, widgets, image alt text and theme strings are not translated.
* URLs are not language-prefixed; translations use translated slugs. Archives/shop show one language at a time via ?lang=xx (optionally remembered by cookie).
* WooCommerce: translated products mirror price/stock from the original; the cart always holds the original product, so cart/checkout text follows your default product names.

== Developer API ==
wpaml_switcher(), wpaml_get_translation_url($post_id,$lang)
Actions: wpaml_translated, wpaml_translation_created, wpaml_translation_approved
