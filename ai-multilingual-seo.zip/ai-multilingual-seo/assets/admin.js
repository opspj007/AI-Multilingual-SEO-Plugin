(function ($) {
	function post(data) {
		return $.post(WPAML.ajax, $.extend({ action: 'wpaml_translate', nonce: WPAML.nonce }, data));
	}

	// Single translate / blank draft / re-translate buttons
	$(document).on('click', '.wpaml-translate', function (e) {
		e.preventDefault();
		var $b = $(this), force = $b.data('force') ? 1 : 0, mode = $b.data('mode') || 'ai', orig = $b.text();
		if (force && !window.confirm(WPAML.i18n.confirm)) return;
		$b.prop('disabled', true).text(mode === 'blank' ? '…' : WPAML.i18n.working);
		post({ post_id: $b.data('post'), lang: $b.data('lang'), mode: mode, force: force })
			.done(function (r) {
				if (r.success) { window.location.reload(); }
				else { window.alert((r.data && r.data.message) || WPAML.i18n.error); $b.prop('disabled', false).text(orig); }
			})
			.fail(function () { window.alert(WPAML.i18n.error); $b.prop('disabled', false).text(orig); });
	});

	// Bulk translation: sequential queue (one request per post+language) so nothing times out
	$('#wpaml-bulk-run').on('click', function () {
		var posts = $('.wpaml-post:checked').map(function () { return $(this).val(); }).get(),
			langs = $('.wpaml-lang:checked').map(function () { return $(this).val(); }).get(),
			skip = $('#wpaml-skip-existing').is(':checked'),
			queue = [], $log = $('#wpaml-log').empty(), $btn = $(this);
		if (!posts.length || !langs.length) { window.alert('Select at least one post and one language.'); return; }
		posts.forEach(function (p) { langs.forEach(function (l) { queue.push([p, l]); }); });
		$btn.prop('disabled', true);
		(function next() {
			var job = queue.shift();
			if (!job) { $btn.prop('disabled', false); $log.append('<li>' + WPAML.i18n.done + '</li>'); return; }
			var $li = $('<li>').text('#' + job[0] + ' → ' + job[1] + ' …').appendTo($log);
			post({ post_id: job[0], lang: job[1], mode: 'ai', force: 0 }).done(function (r) {
				if (r.success) $li.addClass('ok').html('#' + job[0] + ' → ' + job[1] + ': <a href="' + r.data.review + '">review</a>');
				else if (skip && /already exists/i.test(r.data.message)) $li.text('#' + job[0] + ' → ' + job[1] + ': skipped (exists)');
				else $li.addClass('err').text('#' + job[0] + ' → ' + job[1] + ': ' + r.data.message);
			}).fail(function () { $li.addClass('err').text('#' + job[0] + ' → ' + job[1] + ': request failed'); })
			  .always(next);
		})();
	});

	// Live SEO length counters
	function count() {
		var $i = $(this), max = parseInt($i.data('max'), 10), n = $i.val().length, $c = $i.nextAll('.wpaml-count').first();
		$c.text(n + ' / ' + max).toggleClass('over', n > max);
	}
	$(document).on('input', '[data-max]', count);
	$('[data-max]').each(count);
})(jQuery);
